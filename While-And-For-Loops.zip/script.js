// While Loop

var num = 0;

*while (num < 100) {
 num += 1;
 console.log(num); 
}

//For Loop

for (let num = 0; num < 100; num++) {
  console.log(num);
}

