//Array

let fruits = ['banana', 'apple', 'orange', 'pineapples'];

fruits = new Array('banana', 'apple', 'orange', 'pineapples');

console.log(fruits[1]);

fruits[0] = 'pear';
console.log(fruits);

for (let i = 0; i < fruits.length; i++) {
  console.log(fruits[i]);
}

//Array common method

console.log('to string', fruits.toString());
console.log(fruits.join('-'));
console.log(fruits, fruits.pop(), fruits);  //remove last item
console.log(fruits.push('blackberries'), fruits);  //appends
console.log(fruits[3]);

fruits[fruits.length] = 'new fruit' // same as push
console.log(fruits);

fruits.shift(); // removes first item fron an Array
console.log(fruits);

fruits.unshift('kiwi');  // add first item fron an Array
console.log(fruits);

let vegetables = ['ladyfinger', 'tamato', 'broccoli'];
let allGroceries = fruits.concat(vegetables);
console.log(allGroceries);

console.log(allGroceries.slice(1, 4));
console.log(allGroceries.reverse());
console.log(allGroceries.sort());

let someNums = [5, 3, 9, 1];
console.log(someNums.sort());

someNums.sort(function(a, b){return b-a}); //sort in desending order
console.log(someNums);

let emptyArray = new Array();
for (let num - 0; num <= 10; num++) {
  emptyArray.push(num);
}
console.log(emptyArray);

 