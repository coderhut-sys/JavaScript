// strings in java (common methods)

let fruit = 'banana';
let moreFurits = 'banana\napple';   //new line
console.log(moreFurits);          

console.log(fruit.length);
console.log(fruit.indexOf('nan'));
console.log(fruit.slice(2, 6));
console.log(fruit.replace('nan','123'));
console.log(fruit.toUpperCase());
console.log(fruit.toLowerCase());
console.log(fruit.charAt(2));
console.log(fruit[2]);
console.log(fruit.split(''));
console.log(fruit.split(','));
//split by comma for bunch of words