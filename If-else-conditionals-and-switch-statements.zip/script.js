//Conditionals, Control flows (If else)
//only 10 to 20 people can do -----

// && AND
// || OR

let age = prompt('What is your age?');

if ( (age>= 18)  &&  (age <= 35) ) {
  status = 'you can do it';
  console.log(status);
} else {
  status = 'you can not do it';
  console.log(status);
}

/* switch statements

differentitate between weekday vs weekend

day 0 --> sunday --> weekend
day 1 --> monday --> weekday
day 2 --> tuesday --> weekday
day 3 --> wednesday --> weekday
day 4 --> thursday --> weekday
day 5 --> friday --> weekday
day 6 --> sunday --> weekend

*/

switch  (2) {  // you can put any num insted of '2'
     case 0:
          Text = 'weekend';
          break;
     case 6:
          Text = 'weekend';
          break;
     default:
          Text = 'weekday';     
}

console.log(Text);