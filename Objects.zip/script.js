//objects in java

let student = {
  first: 'ishan', 
  last: 'qazi',
  age:12 ,
  hight:121 ,
  studentInfo: function() {
   return this.first + '\n' + this.last + '\n' + this.age + '\n' + this.hight ;  
  }
};

console.log(student.first);
console.log(student.last);

student.first = 'notIshan'    //canage value
console.log(student.first);

student.age++;
console.log(student.age);

console.log(student.studentInfo())

