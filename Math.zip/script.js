//numbers in java
 var num1 = 10;

//math in java
  console.log(5*10);
  console.log(50/5);
  console.log(50+50);
  console.log(100-5);

//increment in numbers

  num1 = num1 + 1;
  console.log(num1);

  num1++;
  console.log(num1);

//decremnt in numbers

  num1 = num1 - 1;
  console.log(num1);

  num1--;
  console.log(num1);

//reaminder %

  console.log(num1 % 6);

//increment and decremnt with 10  

 num1 += 10;
 console.log(num1);



