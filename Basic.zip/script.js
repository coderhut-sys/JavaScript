console.log('hello');
console.log('this is ishan pt. singh');
alert('yooooo');

//this is how to write a comment

//variables

var x ='something';
console.log(x);

var SomeNums = 45;
console.log(SomeNums);

var age = prompt('What is your age?');

document.getElementById('age_fill').innerHTML = age;


