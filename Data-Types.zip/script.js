// Data Types

let your age =18; // number
let yout name = 'Bob'; //string
let name ={first:'Ishan', last:'Singh'}; //object
let truth = false; //boolean
let groceries = ['apple','banana','oranges']; //array
let random; //undifined
let nothing = null; // value null