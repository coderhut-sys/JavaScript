//funtions
  
function fun() {
  console.log('this is a funtion')
}

fun(); 

/*
input = ishan
output = hi ishan
*/

var name = prompt('What is your name?')

function greeting(name)  {
 var result = 'Hello' + ' ' + name; //string concatenation
 console.log(result)
}

 greeting(name); 

//arguments in a funtion

function sumNumbers(num1,num2) {
 var sum = num1 + num2;
 console.log(sum);
}

sumNumbers('Hello', ' Ishan');